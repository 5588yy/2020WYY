# -*- encoding=utf8 -*-
__author__ = "Ning"

from airtest.core.api import *

auto_setup(__file__)

touch(Template(r"tpl1607259985268.png", record_pos=(-0.004, -0.292), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260011830.png", record_pos=(-0.039, -0.49), resolution=(486, 904)))

touch(Template(r"tpl1607260134499.png", record_pos=(-0.169, 0.829), resolution=(486, 904)))

sleep(1.0)

touch(Template(r"tpl1607260150334.png", record_pos=(-0.422, -0.877), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260166839.png", record_pos=(-0.121, 0.85), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260182519.png", record_pos=(-0.033, 0.01), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260198944.png", record_pos=(-0.039, -0.163), resolution=(486, 904)))
touch(Template(r"tpl1607260211686.png", record_pos=(0.22, 0.866), resolution=(486, 904)))
touch(Template(r"tpl1607260226965.png", record_pos=(-0.014, -0.165), resolution=(486, 904)))

touch(Template(r"tpl1607260236400.png", record_pos=(0.226, 0.868), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260247894.png", record_pos=(-0.43, -0.879), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260260769.png", record_pos=(0.115, 0.833), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260276853.png", record_pos=(-0.014, -0.107), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260307589.png", record_pos=(-0.019, -0.619), resolution=(486, 904)))
sleep(1.0)
text("hehheheh")
touch(Template(r"tpl1607260335532.png", record_pos=(-0.15, -0.255), resolution=(486, 904)))

sleep(1.0)
touch(Template(r"tpl1607260350024.png", record_pos=(-0.422, -0.874), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260364578.png", record_pos=(0.366, 0.848), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260378603.png", record_pos=(-0.372, -0.461), resolution=(486, 904)))
touch(Template(r"tpl1607260436540.png", record_pos=(-0.023, -0.202), resolution=(486, 904)))
sleep(1.0)
touch(Template(r"tpl1607260472409.png", record_pos=(-0.426, -0.874), resolution=(486, 904)))
sleep(1.0)


touch(Template(r"tpl1607260421890.png", record_pos=(-0.13, -0.457), resolution=(486, 904)))
touch(Template(r"tpl1607260486560.png", record_pos=(0.128, -0.461), resolution=(486, 904)))
touch(Template(r"tpl1607260508572.png", record_pos=(0.364, -0.467), resolution=(486, 904)))
touch(Template(r"tpl1607260516185.png", record_pos=(0.002, -0.27), resolution=(486, 904)))






