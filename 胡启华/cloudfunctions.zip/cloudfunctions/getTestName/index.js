// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"first-2gtukxdz9c8b6bfa"
})
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  var TestNames_from_Database = db.collection("Test").field({
    TestName:true,
    _id:false
  }).get()
  /*var TestNames_sendTo_User = []
  for(var i in TestNames_from_Database){
    var nowData = TestNames_sendTo_User[i]
    TestNames_sendTo_User.push({
      TestName:nowData.TestName
    })
  }*/
  return await TestNames_from_Database
  
}