// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"first-2gtukxdz9c8b6bfa"
})
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  var re = db.collection("Test").where({
    TestName:event.Type
  }).field({
    _id:false,
    TestList:true
  }).get()
  return await re
}