// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"first-2gtukxdz9c8b6bfa"
})
const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  var SelectList_from_Database = db.collection("TestSelect").where({
    TestName:event.Type
  }).field({
    _id:false,
    TestSelectList:true
  }).get()
  return SelectList_from_Database
}