// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  var TestName = event.TestName
  var Score = event.Score
  var Result
  if(TestName==="焦虑自评量表"){
    if(Score<40){
      Result = "正常"
    }else if(Score>=40&&Score<49){
      Result = "轻度焦虑"
    }else if(Score>=49&&Score<57){
      Result = "中度焦虑"
    }else if(Score>=57){
      Result = "重度焦虑"
    }
  }else if(TestName==="抑郁自评量表"){
    if(Score<40){
      Result = "无抑郁"
    }else if(Score>=40&&Score<49){
      Result = "轻度抑郁"
    }else if(Score>=49&&Score<57){
      Result = "中度抑郁"
    }else if(Score>=57){
      Result = "重度抑郁"
    }
  }else if(TestName==="乐观性测试"){
    if(Score<8){
      Result = "你是个标准的悲观者，看人生总是看到不好的那一面。身为悲观者，唯一的好处是，由于你从来不往好处想，所以你也就很少失望过。然而，以悲观的态度面对人生，却有太多的晦气;你随时会担心失败，因此宁愿不去尝试新的事物，尤其当遇到困难时，你的悲观会让你觉得人生更灰暗、无法接受。悲观会使人产生悲痛、狐疑、恐惧、气愤和挫折的心理。解决这种状况的唯一办法，是以积极的态度来面对每一件事或每一个人，即使你偶尔仍会感到失望，但逐渐地，你会对人生增加信心，胜过原来消极态度带给你的影响。"
    }else if(Score>=8&&Score<15){
      Result = "你对人生的态度比较正常。不过，你仍然可以更进一步，只要你学会怎样以积极和乐天的态度来应付人生中无法避免的起伏情况。"
    }else if(Score>=15&&Score<21){
      Result = "你是个标准的乐天主义者。你看人生总是看到好的那一面，将失望和困难摆到旁边去。乐天，使人活得更有力，不过，要记住，有时候过分乐天，也会造成你对事情掉以轻心，结果反而误事。"
    }
  }
  return await Result
}