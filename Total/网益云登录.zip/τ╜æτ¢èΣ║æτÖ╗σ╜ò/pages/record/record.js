// pages/i_like/i_like.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    menuitems: [
      {  text1:"孩子在为谁玩",text2:"动物寓言",image:"/image/pro_logo.png"},
      {  text1:"做永远成长的苹果树",text2:"成长寓言",image:"/image/pro_logo1.png"},
      {  text1:"把一张纸叠51次",text2:"规划寓言",image:"/image/pro_logo2.png"},
      {  text1:"小猫逃开影子的招数",text2:"逃避寓言",image:"/image/pro_logo3.png"},
      {  text1:"人生的规划",text2:"规划寓言",image:"/image/pro_logo4.png"}
      // 这里需要点击后把图片的信息加入menuitems数组中
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})